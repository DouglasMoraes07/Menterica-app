// shared/_core/errors.ts
// Tratamento de erros compartilhado

export class AppError extends Error {
  constructor(
    public message: string,
    public code: string = "INTERNAL_SERVER_ERROR",
    public status: number = 500
  ) {
    super(message);
    this.name = "AppError";
  }
}

export function ForbiddenError(message: string = "Acesso negado") {
  return new AppError(message, "FORBIDDEN", 403);
}

export function BadRequestError(message: string) {
  return new AppError(message, "BAD_REQUEST", 400);
}

export function NotFoundError(message: string = "Recurso não encontrado") {
  return new AppError(message, "NOT_FOUND", 404);
}
