// shared/const.ts
// Constantes compartilhadas entre cliente e servidor

export const COOKIE_NAME = "menterica_session";
export const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;
export const APP_NAME = "MenteRica";
export const APP_DESCRIPTION = "Plataforma de bem-estar financeiro e emocional.";

// Limites de conteúdo
export const MAX_CONTENT_LENGTH = 20000;
export const MAX_TITLE_LENGTH = 1200;
