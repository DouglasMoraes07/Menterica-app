// client/src/const.ts
// Versão externa - login próprio, sem Manus OAuth
export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

/**
 * Retorna URL da página de login
 * Agora aponta para /login interno em vez do Manus OAuth
 */
export const getLoginUrl = (returnPath?: string) => {
  const base = "/login";
  if (returnPath) {
    return `${base}?redirect=${encodeURIComponent(returnPath)}`;
  }
  return base;
};
