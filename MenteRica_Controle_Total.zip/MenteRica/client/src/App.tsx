// client/src/App.tsx
// Componente principal com roteamento frontend
import React from "react";
import { Switch, Route, Redirect } from "wouter";
import Login from "@/pages/Login";

// Componente simples de Dashboard (Exemplo)
const Dashboard = () => (
  <div className="p-8 text-center">
    <h1 className="text-3xl font-bold mb-4">Bem-vindo ao MenteRica</h1>
    <p className="text-muted-foreground">Você está logado no seu dashboard externo.</p>
    <a href="/login" className="text-primary hover:underline mt-4 inline-block">Sair</a>
  </div>
);

function App() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/dashboard" component={Dashboard} />
      
      {/* Redirecionar para login por padrão */}
      <Route path="/">
        <Redirect to="/login" />
      </Route>
      
      {/* 404 */}
      <Route>
        <div className="p-8 text-center">
          <h1 className="text-2xl font-bold">404 - Página não encontrada</h1>
          <a href="/" className="text-primary hover:underline mt-2 inline-block">Voltar ao início</a>
        </div>
      </Route>
    </Switch>
  );
}

export default App;
