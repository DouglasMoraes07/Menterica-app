// client/src/hooks/use-toast.ts
// Hook simplificado para notificações de toast no frontend
import { useState, useEffect } from "react";

type ToastType = "default" | "destructive" | "success";

interface Toast {
  id: string;
  title?: string;
  description?: string;
  variant?: ToastType;
}

let toastCount = 0;
const subscribers = new Set<(toasts: Toast[]) => void>();
let toasts: Toast[] = [];

const notify = () => {
  subscribers.forEach((cb) => cb([...toasts]));
};

export function toast({ title, description, variant = "default" }: Omit<Toast, "id">) {
  const id = String(++toastCount);
  const newToast = { id, title, description, variant };
  toasts = [...toasts, newToast];
  notify();

  setTimeout(() => {
    toasts = toasts.filter((t) => t.id !== id);
    notify();
  }, 5000);
}

export function useToast() {
  const [currentToasts, setCurrentToasts] = useState<Toast[]>(toasts);

  useEffect(() => {
    const cb = (newToasts: Toast[]) => setCurrentToasts(newToasts);
    subscribers.add(cb);
    return () => {
      subscribers.delete(cb);
    };
  }, []);

  return {
    toasts: currentToasts,
    toast,
  };
}
