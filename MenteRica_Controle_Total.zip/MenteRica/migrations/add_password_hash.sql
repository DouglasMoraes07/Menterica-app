-- Migração: Adicionar coluna de senha na tabela users
-- Execute este SQL no seu banco de dados MySQL

ALTER TABLE users ADD COLUMN passwordHash VARCHAR(255) NULL;
