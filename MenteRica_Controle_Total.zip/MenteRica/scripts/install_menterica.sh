#!/bin/bash

# Script de Instalação Automatizada para MenteRica em Ubuntu 22.04+
# Este script irá configurar seu VPS para rodar o projeto MenteRica.
# Por favor, revise e personalize antes de executar.

# --- Variáveis de Configuração (EDITAR ANTES DE EXECUTAR) ---
PROJECT_DIR="/var/www/menterica"
GIT_REPO="https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git" # Ex: https://github.com/meu-usuario/menterica.git
DOMAIN="seu-dominio.com" # Ex: menterica.click
DB_NAME="menterica"
DB_USER="menterica"
DB_PASSWORD="SUA_SENHA_DO_BANCO" # Altere para uma senha forte

# --- Funções Auxiliares ---
log_info() { echo -e "\e[32m[INFO]\e[0m $1"; }
log_warn() { echo -e "\e[33m[WARN]\e[0m $1"; }
log_error() { echo -e "\e[31m[ERROR]\e[0m $1"; exit 1; }

# --- 1. Atualizar o Sistema ---
log_info "Atualizando o sistema..."
sudo apt update && sudo apt upgrade -y || log_error "Falha ao atualizar o sistema."

# --- 2. Instalar Node.js 22 e pnpm ---
log_info "Instalando Node.js 22..."
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs || log_error "Falha ao instalar Node.js."

log_info "Instalando pnpm..."
sudo npm install -g pnpm || log_error "Falha ao instalar pnpm."

# --- 3. Instalar PM2 ---
log_info "Instalando PM2..."
sudo npm install -g pm2 || log_error "Falha ao instalar PM2."

# --- 4. Instalar MySQL Server ---
log_info "Instalando MySQL Server..."
sudo apt install mysql-server -y || log_error "Falha ao instalar MySQL Server."

log_warn "Por favor, execute 'sudo mysql_secure_installation' manualmente após este script para proteger seu MySQL."

# --- 5. Criar Banco de Dados e Usuário MySQL ---
log_info "Criando banco de dados e usuário MySQL..."
sudo mysql -e "CREATE DATABASE ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" || log_error "Falha ao criar banco de dados."
sudo mysql -e "CREATE USER '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASSWORD}';" || log_error "Falha ao criar usuário do banco de dados."
sudo mysql -e "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';" || log_error "Falha ao conceder privilégios."
sudo mysql -e "FLUSH PRIVILEGES;" || log_error "Falha ao recarregar privilégios do MySQL."

# --- 6. Instalar Nginx ---
log_info "Instalando Nginx..."
sudo apt install nginx -y || log_error "Falha ao instalar Nginx."

# --- 7. Instalar Certbot para SSL ---
log_info "Instalando Certbot..."
sudo apt install certbot python3-certbot-nginx -y || log_error "Falha ao instalar Certbot."

# --- 8. Clonar o Projeto ---
log_info "Clonando o repositório do projeto..."
sudo mkdir -p ${PROJECT_DIR}
sudo chown -R ubuntu:ubuntu ${PROJECT_DIR}
cd ${PROJECT_DIR} || log_error "Diretório do projeto não encontrado."
git clone ${GIT_REPO} . || log_error "Falha ao clonar o repositório. Verifique o GIT_REPO."

# --- 9. Configurar .env (Instrução Manual) ---
log_warn "Por favor, crie e edite o arquivo .env em ${PROJECT_DIR}/.env com suas credenciais."
log_warn "Você pode copiar o .env.example como base: cp .env.example .env"
read -p "Pressione Enter para continuar após configurar o .env..." 

# --- 10. Instalar Dependências e Build ---
log_info "Instalando dependências do projeto..."
pnpm install || log_error "Falha ao instalar dependências do pnpm."

log_info "Realizando build do projeto..."
pnpm build || log_error "Falha ao realizar build do projeto."

# --- 11. Executar Migrações SQL (Instrução Manual) ---
log_warn "Por favor, execute as migrações SQL manualmente no seu banco de dados MySQL."
log_warn "O arquivo de migração está em ${PROJECT_DIR}/migrations/add_password_hash.sql"
log_warn "Exemplo: sudo mysql -u ${DB_USER} -p${DB_PASSWORD} ${DB_NAME} < ${PROJECT_DIR}/migrations/add_password_hash.sql"
read -p "Pressione Enter para continuar após executar as migrações..." 

# --- 12. Configurar Nginx para o Projeto ---
log_info "Configurando Nginx..."
NGINX_CONF="
server {
    listen 80;
    server_name ${DOMAIN} www.${DOMAIN};
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ${DOMAIN} www.${DOMAIN};

    ssl_certificate /etc/letsencrypt/live/${DOMAIN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${DOMAIN}/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
"
echo "${NGINX_CONF}" | sudo tee /etc/nginx/sites-available/${DOMAIN} > /dev/null
sudo ln -sf /etc/nginx/sites-available/${DOMAIN} /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx || log_error "Falha ao configurar Nginx. Verifique a sintaxe."

# --- 13. Obter Certificado SSL com Certbot ---
log_info "Obtendo certificado SSL com Certbot..."
sudo certbot --nginx -d ${DOMAIN} -d www.${DOMAIN} --non-interactive --agree-tos -m seu-email@exemplo.com || log_error "Falha ao obter certificado SSL. Verifique seu domínio e DNS."

# --- 14. Configurar e Iniciar com PM2 ---
log_info "Configurando e iniciando o aplicativo com PM2..."
PM2_ECOSYSTEM_CONF="
{
  \"apps\": [
    {
      \"name\": \"menterica\",
      \"script\": \"dist/index.js\",
      \"instances\": 1,
      \"exec_mode\": \"fork\",
      \"env\": {
        \"NODE_ENV\": \"production\",
        \"PORT\": \"3000\"
      },
      \"error_file\": \"/var/log/menterica/error.log\",
      \"out_file\": \"/var/log/menterica/out.log\",
      \"log_date_format\": \"YYYY-MM-DD HH:mm:ss\"
    }
  ]
}
"
mkdir -p /var/log/menterica || log_error "Falha ao criar diretório de logs."
echo "${PM2_ECOSYSTEM_CONF}" | sudo tee ${PROJECT_DIR}/ecosystem.config.json > /dev/null
pm2 start ${PROJECT_DIR}/ecosystem.config.json || log_error "Falha ao iniciar o aplicativo com PM2."
pm2 save || log_error "Falha ao salvar configuração do PM2."
pm2 startup || log_error "Falha ao configurar PM2 para iniciar no boot."

log_info "Instalação e configuração do MenteRica concluídas com sucesso!"
log_info "Seu site deve estar acessível em https://${DOMAIN}"
log_warn "Lembre-se de configurar seu DNS para apontar para o IP do seu VPS."
log_warn "Verifique os logs do PM2 com 'pm2 logs menterica' para depuração, se necessário."
