// server/db.ts
// Configuração do banco de dados MySQL com Drizzle ORM
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import * as schema from "./schema";
import { ENV } from "./_core/env";
import { eq, sql } from "drizzle-orm";

// Criar pool de conexão
const connection = await mysql.createConnection(ENV.databaseUrl);
export const db = drizzle(connection, { schema, mode: "default" });

// Exportar tabelas para facilitar o acesso
export const { users } = schema;

/**
 * Busca usuário por openId
 */
export async function getUserByOpenId(openId: string) {
  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);
  return result[0] ?? null;
}

/**
 * Upsert usuário
 */
export async function upsertUser(userData: Partial<typeof users.$inferInsert> & { openId: string }) {
  const existing = await getUserByOpenId(userData.openId);
  
  if (existing) {
    await db
      .update(users)
      .set(userData)
      .where(eq(users.openId, userData.openId));
  } else {
    await db.insert(users).values(userData as any);
  }
}

// ===== FUNÇÕES ADICIONAIS PARA AUTH PRÓPRIO =====

/**
 * Busca usuário por email
 */
export async function getUserByEmail(email: string) {
  const result = await db
    .select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1);
  return result[0] ?? null;
}

/**
 * Salva hash de senha do usuário
 */
export async function setUserPassword(openId: string, hashedPassword: string) {
  await db
    .update(users)
    .set({ passwordHash: hashedPassword } as any)
    .where(eq(users.openId, openId));
}

/**
 * Busca hash de senha do usuário
 */
export async function getUserPassword(openId: string): Promise<string | null> {
  const result = await db
    .select({ passwordHash: sql<string>`passwordHash` })
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);
  return result[0]?.passwordHash ?? null;
}
