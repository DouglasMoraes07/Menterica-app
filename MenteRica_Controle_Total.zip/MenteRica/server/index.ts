// server/index.ts
// Ponto de entrada do servidor Express
import express from "express";
import cors from "cors";
import path from "node:path";
import { registerOAuthRoutes } from "./_core/oauth";
import { ENV } from "./_core/env";

const app = express();
const port = ENV.isProduction ? (process.env.PORT || 3000) : 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rotas de Autenticação
registerOAuthRoutes(app);

// Rotas da API (Exemplo)
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Servir arquivos estáticos do Frontend em Produção
if (ENV.isProduction) {
  const distPath = path.resolve(process.cwd(), "dist/public");
  app.use(express.static(distPath));
  
  app.get("*", (req, res) => {
    res.sendFile(path.join(distPath, "index.html"));
  });
}

app.listen(port, () => {
  console.log(`[Server] Servidor rodando em ${ENV.appUrl}`);
  console.log(`[Server] Ambiente: ${ENV.isProduction ? "Produção" : "Desenvolvimento"}`);
});
