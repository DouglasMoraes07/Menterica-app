// server/_core/env.ts
// Versão externa - sem dependência do Manus
export const ENV = {
  // App
  appUrl: process.env.APP_URL ?? "http://localhost:3000",
  cookieSecret: process.env.JWT_SECRET ?? "",
  isProduction: process.env.NODE_ENV === "production",

  // Database
  databaseUrl: process.env.DATABASE_URL ?? "",

  // OpenAI (substitui forgeApiUrl/forgeApiKey)
  openaiApiKey: process.env.OPENAI_API_KEY ?? "",

  // S3 Storage
  s3Bucket: process.env.S3_BUCKET ?? "",
  s3Region: process.env.S3_REGION ?? "us-east-1",
  s3AccessKey: process.env.S3_ACCESS_KEY ?? "",
  s3SecretKey: process.env.S3_SECRET_KEY ?? "",
  s3Endpoint: process.env.S3_ENDPOINT ?? "",

  // Hotmart
  hotmartToken: process.env.HOTMART_TOKEN ?? "",

  // Stripe
  stripeSecretKey: process.env.STRIPE_SECRET_KEY ?? "",
  stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET ?? "",
};
