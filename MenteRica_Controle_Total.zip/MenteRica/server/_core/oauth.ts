// server/_core/oauth.ts
// Versão externa - autenticação própria com email/senha + JWT
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import type { Express, Request, Response } from "express";
import * as db from "../db";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";
import bcrypt from "bcryptjs";

function getQueryParam(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

export function registerOAuthRoutes(app: Express) {
  // ===== REGISTRO =====
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { email, password, name } = req.body;

      if (!email || !password || !name) {
        res.status(400).json({ error: "Email, senha e nome são obrigatórios" });
        return;
      }

      // Verificar se email já existe
      const existingUser = await db.getUserByEmail(email);
      if (existingUser) {
        res.status(409).json({ error: "Email já cadastrado" });
        return;
      }

      // Hash da senha
      const hashedPassword = await bcrypt.hash(password, 12);

      // Criar usuário
      const openId = `local_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      await db.upsertUser({
        openId,
        name,
        email,
        loginMethod: "email",
        lastSignedIn: new Date(),
      });

      // Salvar senha (adicionar coluna password na tabela users)
      await db.setUserPassword(openId, hashedPassword);

      // Criar token JWT
      const sessionToken = await sdk.createSessionToken(openId, {
        name,
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      res.json({ success: true, user: { name, email } });
    } catch (error: any) {
      console.error("[Auth] Register failed:", error);
      res.status(500).json({ error: "Erro ao criar conta" });
    }
  });

  // ===== LOGIN =====
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        res.status(400).json({ error: "Email e senha são obrigatórios" });
        return;
      }

      // Buscar usuário
      const user = await db.getUserByEmail(email);
      if (!user) {
        res.status(401).json({ error: "Email ou senha incorretos" });
        return;
      }

      // Verificar senha
      const storedPassword = await db.getUserPassword(user.openId);
      if (!storedPassword) {
        res.status(401).json({ error: "Email ou senha incorretos" });
        return;
      }

      const isValid = await bcrypt.compare(password, storedPassword);
      if (!isValid) {
        res.status(401).json({ error: "Email ou senha incorretos" });
        return;
      }

      // Atualizar último login
      await db.upsertUser({
        openId: user.openId,
        lastSignedIn: new Date(),
      });

      // Criar token JWT
      const sessionToken = await sdk.createSessionToken(user.openId, {
        name: user.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      res.json({ success: true, user: { name: user.name, email: user.email } });
    } catch (error: any) {
      console.error("[Auth] Login failed:", error);
      res.status(500).json({ error: "Erro ao fazer login" });
    }
  });

  // ===== MANTER CALLBACK ANTIGO (compatibilidade) =====
  app.get("/api/oauth/callback", async (req: Request, res: Response) => {
    res.redirect(302, "/login");
  });
}

// Instalar dependência:
// pnpm add bcryptjs
// pnpm add -D @types/bcryptjs
