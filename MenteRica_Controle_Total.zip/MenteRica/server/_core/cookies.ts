// server/_core/cookies.ts
// Gerenciamento de cookies de sessão
import type { Request, CookieOptions } from "express";
import { ONE_YEAR_MS } from "@shared/const";
import { ENV } from "./env";

export function getSessionCookieOptions(req: Request): CookieOptions {
  return {
    httpOnly: true,
    secure: ENV.isProduction,
    sameSite: "lax",
    path: "/",
    maxAge: ONE_YEAR_MS,
  };
}
