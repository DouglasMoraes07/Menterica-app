// server/_core/notification.ts
// Versão externa - usa email ou webhook próprio
import { TRPCError } from "@trpc/server";

export type NotificationPayload = {
  title: string;
  content: string;
};

const TITLE_MAX_LENGTH = 1200;
const CONTENT_MAX_LENGTH = 20000;

const trimValue = (value: string): string => value.trim();

const isNonEmptyString = (value: unknown): value is string =>
  typeof value === "string" && value.trim().length > 0;

const validatePayload = (input: NotificationPayload): NotificationPayload => {
  if (!isNonEmptyString(input.title)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Notification title is required" });
  }
  if (!isNonEmptyString(input.content)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Notification content is required" });
  }

  const title = trimValue(input.title);
  const content = trimValue(input.content);

  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({ code: "BAD_REQUEST", message: `Title must be at most ${TITLE_MAX_LENGTH} characters` });
  }
  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({ code: "BAD_REQUEST", message: `Content must be at most ${CONTENT_MAX_LENGTH} characters` });
  }

  return { title, content };
};

/**
 * Notifica o dono do projeto
 * Opção 1: Console log (padrão)
 * Opção 2: Integre com Telegram Bot, Discord Webhook, ou Email
 */
export async function notifyOwner(payload: NotificationPayload): Promise<boolean> {
  const { title, content } = validatePayload(payload);

  // Log no console (sempre funciona)
  console.log(`[NOTIFICATION] ${title}: ${content}`);

  // ===== OPÇÃO: Telegram Bot =====
  // const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  // const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID;
  // if (TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID) {
  //   await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
  //     method: "POST",
  //     headers: { "content-type": "application/json" },
  //     body: JSON.stringify({
  //       chat_id: TELEGRAM_CHAT_ID,
  //       text: `🔔 ${title}\n\n${content}`,
  //       parse_mode: "HTML",
  //     }),
  //   });
  // }

  // ===== OPÇÃO: Discord Webhook =====
  // const DISCORD_WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL;
  // if (DISCORD_WEBHOOK_URL) {
  //   await fetch(DISCORD_WEBHOOK_URL, {
  //     method: "POST",
  //     headers: { "content-type": "application/json" },
  //     body: JSON.stringify({ content: `🔔 **${title}**\n${content}` }),
  //   });
  // }

  return true;
}
