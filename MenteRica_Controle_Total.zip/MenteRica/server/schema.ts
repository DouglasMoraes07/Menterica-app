// server/schema.ts
// Definição das tabelas do banco de dados para Drizzle ORM
import { mysqlTable, varchar, timestamp, text } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  openId: varchar("openId", { length: 255 }).primaryKey(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 255 }).unique(),
  loginMethod: varchar("loginMethod", { length: 50 }),
  lastSignedIn: timestamp("lastSignedIn"),
  passwordHash: varchar("passwordHash", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow(),
});

// Outras tabelas podem ser adicionadas aqui
export const sessions = mysqlTable("sessions", {
  id: varchar("id", { length: 255 }).primaryKey(),
  userId: varchar("userId", { length: 255 }).references(() => users.openId),
  token: text("token"),
  expiresAt: timestamp("expiresAt"),
});
