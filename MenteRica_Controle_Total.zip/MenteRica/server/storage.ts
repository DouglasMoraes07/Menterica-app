// server/storage.ts
// Versão externa - usa AWS S3 diretamente
import { S3Client, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { ENV } from "./_core/env";

const s3Client = new S3Client({
  region: ENV.s3Region,
  endpoint: ENV.s3Endpoint || undefined,
  credentials: {
    accessKeyId: ENV.s3AccessKey,
    secretAccessKey: ENV.s3SecretKey,
  },
  forcePathStyle: true, // Necessário para MinIO/R2
});

function normalizeKey(relKey: string): string {
  return relKey.replace(/^\/+/, "");
}

/**
 * Upload arquivo para S3
 */
export async function storagePut(
  relKey: string,
  data: Buffer | Uint8Array | string,
  contentType = "application/octet-stream"
): Promise<{ key: string; url: string }> {
  const key = normalizeKey(relKey);
  const body = typeof data === "string" ? Buffer.from(data) : data;

  await s3Client.send(
    new PutObjectCommand({
      Bucket: ENV.s3Bucket,
      Key: key,
      Body: body,
      ContentType: contentType,
      ACL: "public-read",
    })
  );

  // URL pública do objeto
  const url = ENV.s3Endpoint
    ? `${ENV.s3Endpoint}/${ENV.s3Bucket}/${key}`
    : `https://${ENV.s3Bucket}.s3.${ENV.s3Region}.amazonaws.com/${key}`;

  return { key, url };
}

/**
 * Gera URL pré-assinada para download
 */
export async function storageGet(
  relKey: string,
  expiresIn = 3600
): Promise<{ key: string; url: string }> {
  const key = normalizeKey(relKey);
  const url = await getSignedUrl(
    s3Client,
    new GetObjectCommand({
      Bucket: ENV.s3Bucket,
      Key: key,
    }),
    { expiresIn }
  );
  return { key, url };
}

// Instalar dependências:
// pnpm add @aws-sdk/client-s3 @aws-sdk/s3-request-presigner
